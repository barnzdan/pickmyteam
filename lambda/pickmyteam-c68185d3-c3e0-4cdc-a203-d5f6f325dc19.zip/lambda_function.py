import boto3
import random
import datetime

def lambda_handler(event, context):
    
    year = datetime.datetime.now().year
    
    s3 = boto3.resource('s3')
    file = s3.Object('pickmyteam.name','r_teams')
    file_contents = file.get()['Body'].read()
    teams = file_contents.decode().split('\n')
    
    rand_team = random.choice(teams[:-1])
    logo = rand_team.split(' ')[-1].lower() + '.gif'
    
    response_string = "Your NFL team for the " + str(year) + " season is: The "
    
    resp = {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
        },
        "body": response_string + rand_team + ',' + logo
    }
    
    return resp